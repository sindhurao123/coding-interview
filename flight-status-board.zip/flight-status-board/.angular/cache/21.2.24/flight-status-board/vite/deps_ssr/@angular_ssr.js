import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  AngularAppEngine,
  IS_DISCOVERING_ROUTES,
  InlineCriticalCssProcessor,
  PrerenderFallback,
  RenderMode,
  createRequestHandler,
  destroyAngularServerApp,
  extractRoutesAndCreateRouteTree,
  getOrCreateAngularServerApp,
  getRoutesFromAngularRouterConfig,
  provideServerRendering,
  setAngularAppEngineManifest,
  setAngularAppManifest,
  withAppShell,
  withRoutes
} from "./chunk-5GRXMECW.js";
import "./chunk-J24ICVIO.js";
import "./chunk-SHSB3GCN.js";
import "./chunk-BT5SRGJ2.js";
import "./chunk-F4RX7FFE.js";
import "./chunk-XD6S33UH.js";
import "./chunk-TAIT63V2.js";
import "./chunk-QGEBPUBO.js";
import "./chunk-S6STQDT5.js";
export {
  AngularAppEngine,
  IS_DISCOVERING_ROUTES,
  PrerenderFallback,
  RenderMode,
  createRequestHandler,
  provideServerRendering,
  withAppShell,
  withRoutes,
  InlineCriticalCssProcessor as ɵInlineCriticalCssProcessor,
  destroyAngularServerApp as ɵdestroyAngularServerApp,
  extractRoutesAndCreateRouteTree as ɵextractRoutesAndCreateRouteTree,
  getOrCreateAngularServerApp as ɵgetOrCreateAngularServerApp,
  getRoutesFromAngularRouterConfig as ɵgetRoutesFromAngularRouterConfig,
  setAngularAppEngineManifest as ɵsetAngularAppEngineManifest,
  setAngularAppManifest as ɵsetAngularAppManifest
};
