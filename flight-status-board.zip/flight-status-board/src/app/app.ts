import { Component } from '@angular/core';
import { FlightBoardComponent } from './flight-board-component/flight-board-component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [ FlightBoardComponent ],
  template: `<app-flight-board />`
})
export class App {
}