import { Component, DestroyRef, inject, OnInit, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { Store } from '@ngxs/store';
import { debounceTime, interval, Subject } from 'rxjs';
import { FlightStatus } from './../models/flight.model';
import { FlightState, LoadFlights, SetDestinationFilter, SetStatusFilter } from './../state/flight.state';
import { DatePipe } from '@angular/common';

const REFRESH_INTERVAL_MS = 10000;
const DESTINATION_DEBOUNCE_MS = 250;

@Component({
  selector: 'app-flight-board',
  templateUrl: './flight-board-component.html',
  styleUrl: './flight-board-component.css',
  imports: [DatePipe]
})
export class FlightBoardComponent implements OnInit {

  private readonly store = inject(Store);
  private readonly destroyRef = inject(DestroyRef);

  readonly flights = this.store.selectSignal(FlightState.visibleFlights);
  readonly loading = this.store.selectSignal(FlightState.loading);
  readonly error = this.store.selectSignal(FlightState.error);
  readonly statusFilter = this.store.selectSignal(FlightState.statusFilter);


  readonly lastUpdated = signal<Date | null>(null);

  private readonly destinationInput = new Subject<string>();

  ngOnInit(): void {
    this.loadFlights();

    interval(REFRESH_INTERVAL_MS)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(() => this.loadFlights());

    this.destinationInput
      .pipe(
        debounceTime(DESTINATION_DEBOUNCE_MS),
        takeUntilDestroyed(this.destroyRef)
      )
      .subscribe(destination => {
        this.store.dispatch(new SetDestinationFilter(destination));
      });
  }

  loadFlights(): void {
    this.store.dispatch(new LoadFlights());
    this.lastUpdated.set(new Date());
  }

  setStatus(status: FlightStatus | 'all'): void {
    this.store.dispatch(new SetStatusFilter(status));
  }

  setDestination(destination: string): void {
    this.destinationInput.next(destination);
  }
}