import { Injectable } from '@angular/core';
import { Action, Selector, State, StateContext } from '@ngxs/store';
import { tap, catchError, of } from 'rxjs';
import { Flight, FlightStatus } from '../models/flight.model';
import { FlightService } from '../services/flight.service';

export interface FlightStateModel {
    flights: Flight[];
    statusFilter: FlightStatus | 'all';
    destinationFilter: string;
    loading: boolean;
    error: string | null;
}

export class LoadFlights {
    static readonly type = 'Flight Load Flights';
}

export class SetStatusFilter {
    static readonly type = 'Flight Set Status Filter';
    constructor(public status: FlightStatus | 'all') { }
}

export class SetDestinationFilter {
    static readonly type = 'Flight Set Destination Filter';
    constructor(public destination: string) { }
}

const VISIBLE_FLIGHT_COUNT = 10;

@State<FlightStateModel>({
    name: 'flights',
    defaults: {
        flights: [],
        statusFilter: 'all',
        destinationFilter: '',
        loading: false,
        error: null
    }
})

@Injectable()
export class FlightState {

    constructor(private readonly flightService: FlightService) { }

    @Selector()
    static rawFlights(state: FlightStateModel): Flight[] {
        return state.flights;
    }

    @Selector()
    static statusFilter(state: FlightStateModel): FlightStatus | 'all' {
        return state.statusFilter;
    }

    @Selector()
    static destinationFilter(state: FlightStateModel): string {
        return state.destinationFilter;
    }

    @Selector()
    static loading(state: FlightStateModel): boolean {
        return state.loading;
    }

    @Selector()
    static error(state: FlightStateModel): string | null {
        return state.error;
    }

    @Selector([FlightState.rawFlights])
    static flightsByStatus(flights: Flight[]): Map<FlightStatus, Flight[]> {
        const byStatus = new Map<FlightStatus, Flight[]>();
        for (const flight of flights) {
            const flightBucket = byStatus.get(flight.status);
            if (flightBucket) {
                flightBucket.push(flight);
            } else {
                byStatus.set(flight.status, [flight]);
            }
        }
        return byStatus;
    }

    @Selector([
        FlightState.rawFlights,
        FlightState.flightsByStatus,
        FlightState.statusFilter,
        FlightState.destinationFilter
    ])
    static visibleFlights(
        flights: Flight[],
        flightsByStatus: Map<FlightStatus, Flight[]>,
        statusFilter: FlightStatus | 'all',
        destinationFilter: string
    ): Flight[] {
        const candidates = statusFilter === 'all'
            ? flights
            : (flightsByStatus.get(statusFilter) ?? []);

        const destination = destinationFilter.trim().toLowerCase();
        const filtered = destination === ''
            ? candidates
            : candidates.filter(flight =>
                flight.destination.toLowerCase().includes(destination)
            );

        return FlightState.topNByArrivalTime(filtered, VISIBLE_FLIGHT_COUNT);
    }

    private static topNByArrivalTime(flights: Flight[], n: number): Flight[] {
        const top: Flight[] = [];

        for (const flight of flights) {
            if (top.length < n) {
                top.push(flight);
                top.sort((a, b) => a.arrivalTime - b.arrivalTime);
            } else if (flight.arrivalTime < top[n - 1].arrivalTime) {
                top[n - 1] = flight;
                top.sort((a, b) => a.arrivalTime - b.arrivalTime);
            }
        }

        return top;
    }

    @Action(LoadFlights)
    loadFlights(ctx: StateContext<FlightStateModel>) {
        ctx.patchState({
            loading: true,
            error: null
        });

        return this.flightService.getFlights().pipe(
            tap(flights => {
                ctx.patchState({ flights, loading: false, error: null });
            }),
            catchError(error => {
                console.error('Failed to load flights', error);
                ctx.patchState({
                    loading: false,
                    error: 'Unable to load flights'
                });
                return of([]);
            })
        );
    }

    @Action(SetStatusFilter)
    setStatusFilter(
        ctx: StateContext<FlightStateModel>,
        action: SetStatusFilter
    ) {
        ctx.patchState({ statusFilter: action.status });
    }

    @Action(SetDestinationFilter)
    setDestinationFilter(
        ctx: StateContext<FlightStateModel>,
        action: SetDestinationFilter
    ) {
        ctx.patchState({ destinationFilter: action.destination });
    }
}